-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2020 at 12:43 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `little_footprints_academy`
--

-- --------------------------------------------------------

--
-- Table structure for table `lit_employee_details`
--

CREATE TABLE `lit_employee_details` (
  `id` int(11) NOT NULL,
  `emp_id` varchar(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `empsin` varchar(15) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(300) NOT NULL,
  `city` varchar(25) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `hire_date` varchar(15) NOT NULL,
  `rehire_date` varchar(15) NOT NULL,
  `empcert` varchar(10) NOT NULL,
  `hour_rate` int(3) NOT NULL,
  `emp_position` int(3) NOT NULL,
  `medical` int(3) NOT NULL,
  `vocation_rate` float NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lit_employee_details`
--

INSERT INTO `lit_employee_details` (`id`, `emp_id`, `first_name`, `last_name`, `empsin`, `dob`, `address1`, `address2`, `city`, `pincode`, `phone`, `email`, `hire_date`, `rehire_date`, `empcert`, `hour_rate`, `emp_position`, `medical`, `vocation_rate`, `status`) VALUES
(1, '001', 'iyappan', 'iyappan', '324-588-734', '16-Jan-2020', 'dsfdsfdsfdsfdsf', 'dfdfsdfdssfs', 'dsdfdfsdfd', 'a1a1a1', '323-3232222', 'djkls@g.com', '08-Jan-2020', '08-Jan-2020', 'ECE-IT', 323, 0, 323, 0.0001, '0');

-- --------------------------------------------------------

--
-- Table structure for table `lit_employee_position`
--

CREATE TABLE `lit_employee_position` (
  `id` int(11) NOT NULL,
  `position` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lit_employee_position`
--

INSERT INTO `lit_employee_position` (`id`, `position`) VALUES
(1, 'Lead Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `lit_payroll`
--

CREATE TABLE `lit_payroll` (
  `id` int(11) NOT NULL,
  `emp_ids` varchar(11) NOT NULL,
  `first_name` varchar(33) NOT NULL,
  `last_name` varchar(33) NOT NULL,
  `per_hr_rate` float NOT NULL,
  `regular_hrs` float NOT NULL,
  `stat_hol` float NOT NULL,
  `wage_amount` float NOT NULL,
  `miscellaneous_amount` float NOT NULL,
  `pay_date` varchar(12) NOT NULL,
  `pay_end_date` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lit_payroll`
--

INSERT INTO `lit_payroll` (`id`, `emp_ids`, `first_name`, `last_name`, `per_hr_rate`, `regular_hrs`, `stat_hol`, `wage_amount`, `miscellaneous_amount`, `pay_date`, `pay_end_date`) VALUES
(54, '001', 'keerthi', 'dfasdf', 11, 11, 11, 213, 12312, '11-Jan-2020', '11-Jan-2020');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lit_employee_details`
--
ALTER TABLE `lit_employee_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lit_employee_position`
--
ALTER TABLE `lit_employee_position`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lit_payroll`
--
ALTER TABLE `lit_payroll`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lit_employee_details`
--
ALTER TABLE `lit_employee_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lit_employee_position`
--
ALTER TABLE `lit_employee_position`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lit_payroll`
--
ALTER TABLE `lit_payroll`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
